#pragma once
#include "esp_err.h"

esp_err_t app_controller_init(void);
